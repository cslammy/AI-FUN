/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const START_OCTAVE = 1;
const NUM_OCTAVES = 4;
// Canonical names for notes in an octave, sharps preferred for black keys internally
const NOTES_IN_OCTAVE = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const NOTE_VALUE_MAP: { [key: string]: number } = {
    'C': 0, 'B#': 0,
    'C#': 1, 'DB': 1,
    'D': 2,
    'D#': 3, 'EB': 3,
    'E': 4, 'FB': 4,
    'F': 5, 'E#':5,
    'F#': 6, 'GB': 6,
    'G': 7,
    'G#': 8, 'AB': 8,
    'A': 9,
    'A#': 10, 'BB': 10,
    'B': 11, 'CB': 11
};

const SHARP_TO_FLAT_MAP: { [sharpNote: string]: string } = {
    'C#': 'Db', 'D#': 'Eb', 'F#': 'Gb', 'G#': 'Ab', 'A#': 'Bb'
};
// const FLAT_TO_SHARP_MAP: { [flatNote: string]: string } = { // Not strictly needed with current canonical form
//     'Db': 'C#', 'Eb': 'D#', 'Gb': 'F#', 'Ab': 'G#', 'Bb': 'A#'
// };


const MIN_NOTE_VALUE = START_OCTAVE * 12 + NOTE_VALUE_MAP[NOTES_IN_OCTAVE[0]]; // C1 (value 12 for octave 1, assuming C0=0)
const MAX_NOTE_VALUE = (START_OCTAVE + NUM_OCTAVES - 1) * 12 + NOTE_VALUE_MAP[NOTES_IN_OCTAVE[NOTES_IN_OCTAVE.length - 1]]; // B4 (value 59 for octave 4)

const WHITE_KEY_INDICES = [0, 2, 4, 5, 7, 9, 11]; // Indices in NOTES_IN_OCTAVE for C, D, E, F, G, A, B

let displayModeForBlackKeys: 'sharps' | 'flats' = 'sharps';
let showAllOctavesMode: boolean = false;

/**
 * Gets the preferred display name for a note (sharp/flat handling).
 * @param noteNameInSharps The canonical sharp name (e.g., C#, D#).
 * @param octave The octave number.
 * @returns The preferred note name string (e.g., C#1 or Db1).
 */
function getPreferredNoteName(noteNameInSharps: string, octave: number): string {
    if (displayModeForBlackKeys === 'flats' && SHARP_TO_FLAT_MAP[noteNameInSharps]) {
        return `${SHARP_TO_FLAT_MAP[noteNameInSharps]}${octave}`;
    }
    return `${noteNameInSharps}${octave}`;
}


/**
 * Converts a numerical MIDI-like note value back to its string name (e.g., 13 -> "C#1" or "Db1").
 * @param noteValue The numerical value of the note.
 * @returns The string representation of the note, respecting sharp/flat display mode.
 */
function getNoteNameFromValue(noteValue: number): string {
    const octave = Math.floor(noteValue / 12);
    const indexInOctave = noteValue % 12;
    const noteNameInSharps = NOTES_IN_OCTAVE[indexInOctave];
    return getPreferredNoteName(noteNameInSharps, octave);
}

/**
 * Parses a note string (e.g., "C4", "F#3", "Bb2") into a numerical MIDI-like value.
 * Note: Octave numbering in this app is 1-based (C1, C2 etc.). Internally, note values are 0-indexed C0=0.
 * So C1 = 12, C2 = 24 etc.
 * @param noteString The note string.
 * @returns The numerical value of the note, or null if invalid.
 */
function parseSingleNote(noteString: string): number | null {
    const match = noteString.trim().match(/^([A-G])([#B]?)([0-9])$/i);
    if (!match) return null;

    let [, noteName, accidental, octaveStr] = match;
    noteName = noteName.toUpperCase();
    const octave = parseInt(octaveStr, 10);

    // Validate octave for practical keyboard range (roughly 0-9)
    if (octave < 0 || octave > 9) return null;


    let normalizedAccidental = '';
    if (accidental) {
        if (accidental.toLowerCase() === 'b') {
            normalizedAccidental = 'B'; 
        } else if (accidental === '#') {
            normalizedAccidental = '#';
        }
    }

    const baseNoteKey = noteName + normalizedAccidental;
    let noteValueInOctave = NOTE_VALUE_MAP[baseNoteKey];

    if (noteValueInOctave === undefined) return null;

    return octave * 12 + noteValueInOctave;
}


/**
 * Parses a string of space-separated notes into an array of numerical values.
 * @param inputString The string of notes.
 * @returns An array of valid note values.
 */
function parseNoteInput(inputString: string): number[] {
    const notes = inputString.trim().split(/\s+/);
    const parsedNotes: number[] = [];
    const errorDiv = document.getElementById('error-message');
    let specificErrorShown = false;

    if (errorDiv && (errorDiv.textContent?.startsWith("Warning:") || errorDiv.textContent?.startsWith("No valid notes") || errorDiv.textContent?.startsWith("Please enter some notes"))) {
       errorDiv.textContent = '';
    }

    notes.forEach(noteStr => {
        if (!noteStr) return;
        const value = parseSingleNote(noteStr);
        if (value !== null) {
            parsedNotes.push(value);
        } else {
            console.warn(`Invalid note format: ${noteStr}`);
            if (errorDiv && !specificErrorShown) {
                errorDiv.textContent = `Warning: "${noteStr}" is not a valid note and was ignored. Format: Note[#b]Octave (e.g., C4, F#3, Bb2).`;
                specificErrorShown = true; 
            }
        }
    });
    return parsedNotes;
}

/**
 * Prepares the list of base notes for display, considering the showAllOctavesMode.
 * @param parsedInputNotes Notes as parsed from input (with specific octaves).
 * @returns Array of note values to use as the basis for "Original Notes" display.
 */
function getNotesForDisplay(parsedInputNotes: number[]): number[] {
    if (!showAllOctavesMode) {
        return parsedInputNotes;
    }

    const expandedNotes: number[] = [];
    const uniqueNoteIndicesInOctave = new Set<number>();

    parsedInputNotes.forEach(noteValue => {
        uniqueNoteIndicesInOctave.add(noteValue % 12);
    });

    uniqueNoteIndicesInOctave.forEach(noteIndex => {
        for (let octave = START_OCTAVE; octave < START_OCTAVE + NUM_OCTAVES; octave++) {
            const noteValue = octave * 12 + noteIndex;
            // Ensure it's within the displayable keyboard range defined by MIN/MAX_NOTE_VALUE
            // Although START_OCTAVE and NUM_OCTAVES should already guarantee this for well-formed noteIndex
            if (noteValue >= MIN_NOTE_VALUE && noteValue <= MAX_NOTE_VALUE) {
                 expandedNotes.push(noteValue);
            }
        }
    });
    return expandedNotes.sort((a, b) => a - b); // Sort for consistent "lowest note"
}


/**
 * Creates a DOM element representing a single keyboard.
 * @param keyboardIdSuffix Suffix for unique IDs if multiple keyboards are on the page.
 * @returns The keyboard DOM element.
 */
function createKeyboardElement(keyboardIdSuffix: string): HTMLElement {
    const keyboardDiv = document.createElement('div');
    keyboardDiv.className = 'keyboard';
    keyboardDiv.setAttribute('role', 'listbox');
    keyboardDiv.setAttribute('aria-label', `Piano keyboard ${keyboardIdSuffix}`);

    for (let octave = START_OCTAVE; octave < START_OCTAVE + NUM_OCTAVES; octave++) {
        NOTES_IN_OCTAVE.forEach((noteNameCanonical, indexInOctave) => { 
            const noteValue = octave * 12 + indexInOctave;
            const isWhiteKey = WHITE_KEY_INDICES.includes(indexInOctave);
            const keyDiv = document.createElement('div');
            
            const displayNoteName = getPreferredNoteName(noteNameCanonical, octave);

            keyDiv.className = `key ${isWhiteKey ? 'white' : 'black'}`;
            keyDiv.dataset.noteValue = String(noteValue);
            keyDiv.setAttribute('role', 'option');
            keyDiv.setAttribute('aria-label', displayNoteName);
            keyDiv.textContent = displayNoteName; 

            if (isWhiteKey) {
                keyboardDiv.appendChild(keyDiv);
            } else {
                const whiteKeyUnitWidth = 100 / (NUM_OCTAVES * 7); 
                
                let precedingWhiteKeysInOctaveForGroup = 0;
                if (noteNameCanonical === 'C#') precedingWhiteKeysInOctaveForGroup = 0; 
                else if (noteNameCanonical === 'D#') precedingWhiteKeysInOctaveForGroup = 1; 
                else if (noteNameCanonical === 'F#') precedingWhiteKeysInOctaveForGroup = 3; 
                else if (noteNameCanonical === 'G#') precedingWhiteKeysInOctaveForGroup = 4; 
                else if (noteNameCanonical === 'A#') precedingWhiteKeysInOctaveForGroup = 5; 
                
                const totalPrecedingWhiteKeys = (octave - START_OCTAVE) * 7 + precedingWhiteKeysInOctaveForGroup;
                
                const blackKeyLeftPercent = (totalPrecedingWhiteKeys + 1) * whiteKeyUnitWidth - (whiteKeyUnitWidth * 0.3); 
                                                                                                                         
                keyDiv.style.left = `${blackKeyLeftPercent}%`;
                keyDiv.style.width = `${whiteKeyUnitWidth * 0.6}%`; 
                keyboardDiv.appendChild(keyDiv);
            }
        });
    }
    return keyboardDiv;
}

/**
 * Highlights a specific note on a given keyboard.
 * @param keyboardElement The keyboard DOM element.
 * @param noteValue The numerical value of the note to highlight.
 * @param highlightClass The CSS class to apply for highlighting.
 */
function highlightKey(keyboardElement: HTMLElement, noteValue: number, highlightClass: string) {
    const keyElement = keyboardElement.querySelector(`.key[data-note-value="${noteValue}"]`) as HTMLElement;
    if (keyElement) {
        keyElement.classList.add(highlightClass);
        keyElement.setAttribute('aria-selected', 'true');
    }
}

function renderTranspositions() {
    const noteInput = document.getElementById('note-input') as HTMLInputElement;
    const keyboardsContainer = document.getElementById('keyboards-container');
    const errorDiv = document.getElementById('error-message');

    if (!noteInput || !keyboardsContainer || !errorDiv) {
        console.error('Required HTML elements not found for rendering.');
        if (errorDiv) {
            errorDiv.textContent = "Error: Core page elements missing. Please try reloading.";
        }
        return;
    }
    
    if (errorDiv.textContent && !errorDiv.textContent.startsWith("Warning:")) {
      errorDiv.textContent = '';
    }

    const parsedInputNotes = parseNoteInput(noteInput.value); 
    
    if (parsedInputNotes.length === 0 && noteInput.value.trim() !== "") {
        if (!errorDiv.textContent) { 
             errorDiv.textContent = 'No valid notes entered. Please use format: Note[#b]Octave (e.g., C4, F#3, Bb2).';
        }
    } else if (parsedInputNotes.length === 0 && noteInput.value.trim() === "") {
         if (!errorDiv.textContent) errorDiv.textContent = 'Please enter some notes to visualize.';
    }

    const baseNotesForDisplay = getNotesForDisplay(parsedInputNotes);

    keyboardsContainer.innerHTML = ''; 

    for (let i = 0; i < 12; i++) { 
        const wrapperDiv = document.createElement('div');
        wrapperDiv.className = 'keyboard-wrapper';

        const titleElement = document.createElement('h3');
        
        const keyboardElement = createKeyboardElement(i === 0 ? 'original' : `transposed-${i}`);
        wrapperDiv.appendChild(titleElement); 
        wrapperDiv.appendChild(keyboardElement);

        let hasHighlightedNotesInRange = false;
        let lowestNoteValueForTitle: number | null = null;
        const highlightedNotesInThisDiagram: number[] = [];

        if (baseNotesForDisplay.length > 0) {
            baseNotesForDisplay.forEach(noteValue => {
                const transposedValue = noteValue + i;
                if (transposedValue >= MIN_NOTE_VALUE && transposedValue <= MAX_NOTE_VALUE) {
                    highlightKey(keyboardElement, transposedValue, 'highlighted');
                    highlightedNotesInThisDiagram.push(transposedValue);
                    hasHighlightedNotesInRange = true;
                }
            });

            if (highlightedNotesInThisDiagram.length > 0) {
                lowestNoteValueForTitle = Math.min(...highlightedNotesInThisDiagram);
            }
        }
        
        let titleText = i === 0 ? 'Original Notes' : `Transposed +${i} Semitone${i > 1 ? 's' : ''}`;
        if (lowestNoteValueForTitle !== null) {
            titleText += `, lowest note: ${getNoteNameFromValue(lowestNoteValueForTitle)}`;
        }
        titleElement.textContent = titleText;


        if (!hasHighlightedNotesInRange && baseNotesForDisplay.length > 0) { 
            const noNotesMessage = document.createElement('p');
            noNotesMessage.className = 'out-of-range-message';
            noNotesMessage.textContent = 'All transposed notes are out of keyboard range.';
            wrapperDiv.appendChild(noNotesMessage);
        }
        keyboardsContainer.appendChild(wrapperDiv);
    }
}

// --- PNG Export ---
const PNG_COLUMNS = 2;
const PNG_KEYBOARD_WIDTH = 400;
const PNG_KEYBOARD_HEIGHT = 120;
const PNG_TITLE_HEIGHT = 25;
const PNG_KEY_TEXT_SIZE = 10;
const PNG_TITLE_TEXT_SIZE = 14;
const PNG_GAP = 15;
const PNG_PADDING = 20;

function drawKeyboardToCanvasContext(
    ctx: CanvasRenderingContext2D,
    notesToHighlight: number[],
    offsetX: number,
    offsetY: number,
    width: number,
    height: number
) {
    ctx.save();
    ctx.translate(offsetX, offsetY);
    ctx.strokeStyle = '#333';
    ctx.lineWidth = 1;
    ctx.strokeRect(0, 0, width, height);
    ctx.fillStyle = '#f0f0f0'; 
    ctx.fillRect(0,0,width,height);


    const numWhiteKeysTotal = NUM_OCTAVES * 7;
    const whiteKeyWidth = width / numWhiteKeysTotal;
    const blackKeyWidth = whiteKeyWidth * 0.6;
    const blackKeyHeight = height * 0.6;

    let currentWhiteKeyX = 0;

    for (let octave = START_OCTAVE; octave < START_OCTAVE + NUM_OCTAVES; octave++) {
        NOTES_IN_OCTAVE.forEach((noteNameCanonical, indexInOctave) => {
            const noteValue = octave * 12 + indexInOctave;
            const isWhiteKey = WHITE_KEY_INDICES.includes(indexInOctave);
            const displayNoteName = getPreferredNoteName(noteNameCanonical, octave);

            if (isWhiteKey) {
                ctx.fillStyle = notesToHighlight.includes(noteValue) ? '#e8491d' : '#fff';
                ctx.fillRect(currentWhiteKeyX, 0, whiteKeyWidth, height);
                ctx.strokeRect(currentWhiteKeyX, 0, whiteKeyWidth, height);
                
                ctx.fillStyle = notesToHighlight.includes(noteValue) ? '#fff' : '#333';
                ctx.font = `${PNG_KEY_TEXT_SIZE}px sans-serif`;
                ctx.textAlign = 'center';
                ctx.textBaseline = 'bottom';
                ctx.fillText(displayNoteName, currentWhiteKeyX + whiteKeyWidth / 2, height - 5);
                currentWhiteKeyX += whiteKeyWidth;
            }
        });
    }
    
    currentWhiteKeyX = 0; // Reset for black key positioning relative to white keys
    for (let octave = START_OCTAVE; octave < START_OCTAVE + NUM_OCTAVES; octave++) {
        NOTES_IN_OCTAVE.forEach((noteNameCanonical, indexInOctave) => {
             const noteValue = octave * 12 + indexInOctave;
             const isWhiteKey = WHITE_KEY_INDICES.includes(indexInOctave);
             const displayNoteName = getPreferredNoteName(noteNameCanonical, octave);

            if (!isWhiteKey) { 
                let precedingWhiteKeysInOctaveForGroup = 0;
                if (noteNameCanonical === 'C#') precedingWhiteKeysInOctaveForGroup = 0;
                else if (noteNameCanonical === 'D#') precedingWhiteKeysInOctaveForGroup = 1;
                else if (noteNameCanonical === 'F#') precedingWhiteKeysInOctaveForGroup = 3;
                else if (noteNameCanonical === 'G#') precedingWhiteKeysInOctaveForGroup = 4;
                else if (noteNameCanonical === 'A#') precedingWhiteKeysInOctaveForGroup = 5;

                const totalPrecedingWhiteKeysBeforeThisBlackKey = (octave - START_OCTAVE) * 7 + precedingWhiteKeysInOctaveForGroup;
                const blackKeyRelativeX = (totalPrecedingWhiteKeysBeforeThisBlackKey + 1) * whiteKeyWidth - (blackKeyWidth / 2) ;

                ctx.fillStyle = notesToHighlight.includes(noteValue) ? '#e8491d' : '#333';
                ctx.fillRect(blackKeyRelativeX, 0, blackKeyWidth, blackKeyHeight);
                ctx.strokeRect(blackKeyRelativeX, 0, blackKeyWidth, blackKeyHeight); 

                ctx.fillStyle = notesToHighlight.includes(noteValue) ? '#333' : '#fff'; 
                ctx.font = `${PNG_KEY_TEXT_SIZE-1}px sans-serif`; 
                ctx.textAlign = 'center';
                ctx.textBaseline = 'bottom';
                ctx.fillText(displayNoteName, blackKeyRelativeX + blackKeyWidth / 2, blackKeyHeight - 3);
            }
        });
    }
    ctx.restore();
}


function handleExportToPng() {
    const noteInput = document.getElementById('note-input') as HTMLInputElement;
    const keyboardsContainer = document.getElementById('keyboards-container');
    const errorDiv = document.getElementById('error-message');

    if (!keyboardsContainer || !errorDiv || !noteInput) {
        if (errorDiv) errorDiv.textContent = "Error: Core page elements missing for PNG export.";
        return;
    }
    if (keyboardsContainer.children.length === 0) {
        if (errorDiv) errorDiv.textContent = 'Please generate the diagrams first by entering notes and clicking "Visualize Transpositions".';
        return;
    }
     if (errorDiv.textContent && !errorDiv.textContent.startsWith("Warning:")) {
      errorDiv.textContent = '';
    }

    const parsedInputNotes = parseNoteInput(noteInput.value);
    if (parsedInputNotes.length === 0 && noteInput.value.trim() !== "") {
         if (!errorDiv.textContent) { 
             errorDiv.textContent = 'No valid notes to export. Please use format: Note[#b]Octave (e.g., C4, F#3, Bb2).';
        }
        return;
    } else if (parsedInputNotes.length === 0 && noteInput.value.trim() === "") {
         if (!errorDiv.textContent) errorDiv.textContent = 'Please enter some notes to export.';
         return;
    }
    
    const baseNotesForPng = getNotesForDisplay(parsedInputNotes);


    const numRows = Math.ceil(12 / PNG_COLUMNS);
    const totalCanvasWidth = PNG_COLUMNS * (PNG_KEYBOARD_WIDTH + PNG_GAP) - PNG_GAP + 2 * PNG_PADDING;
    const totalCanvasHeight = numRows * (PNG_KEYBOARD_HEIGHT + PNG_TITLE_HEIGHT + PNG_GAP) - PNG_GAP + 2 * PNG_PADDING;

    const canvas = document.createElement('canvas');
    canvas.width = totalCanvasWidth;
    canvas.height = totalCanvasHeight;
    const ctx = canvas.getContext('2d');

    if (!ctx) {
        if (errorDiv) errorDiv.textContent = 'Error: Could not create canvas context for PNG export.';
        return;
    }

    ctx.fillStyle = '#ffffff'; 
    ctx.fillRect(0, 0, totalCanvasWidth, totalCanvasHeight);

    let currentX = PNG_PADDING;
    let currentY = PNG_PADDING;

    for (let i = 0; i < 12; i++) {
        const notesToHighlightOnThisKeyboard: number[] = [];
        let hasNotesInRange = false;
        let lowestNoteValueForPngTitle: number | null = null;

        baseNotesForPng.forEach(noteValue => {
            const transposedValue = noteValue + i;
            if (transposedValue >= MIN_NOTE_VALUE && transposedValue <= MAX_NOTE_VALUE) {
                notesToHighlightOnThisKeyboard.push(transposedValue);
                hasNotesInRange = true;
            }
        });
        
        if (notesToHighlightOnThisKeyboard.length > 0) {
            lowestNoteValueForPngTitle = Math.min(...notesToHighlightOnThisKeyboard);
        }

        let titleText = i === 0 ? 'Original Notes' : `Transposed +${i} Semitone${i > 1 ? 's' : ''}`;
        if (lowestNoteValueForPngTitle !== null) {
            titleText += `, lowest note: ${getNoteNameFromValue(lowestNoteValueForPngTitle)}`;
        }
        
        ctx.fillStyle = '#333333';
        ctx.font = `bold ${PNG_TITLE_TEXT_SIZE}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'top';
        const titleMaxWidth = PNG_KEYBOARD_WIDTH; 
        ctx.fillText(titleText, currentX + PNG_KEYBOARD_WIDTH / 2, currentY, titleMaxWidth);


        drawKeyboardToCanvasContext(
            ctx,
            notesToHighlightOnThisKeyboard,
            currentX,
            currentY + PNG_TITLE_HEIGHT,
            PNG_KEYBOARD_WIDTH,
            PNG_KEYBOARD_HEIGHT
        );
        
        if (!hasNotesInRange && baseNotesForPng.length > 0 && notesToHighlightOnThisKeyboard.length === 0) { 
            ctx.fillStyle = '#777777';
            ctx.font = `${PNG_KEY_TEXT_SIZE}px sans-serif`;
            ctx.textAlign = 'center';
            ctx.fillText("All notes out of range", currentX + PNG_KEYBOARD_WIDTH / 2, currentY + PNG_TITLE_HEIGHT + PNG_KEYBOARD_HEIGHT / 2);
        }


        if ((i + 1) % PNG_COLUMNS === 0) { 
            currentX = PNG_PADDING;
            currentY += PNG_KEYBOARD_HEIGHT + PNG_TITLE_HEIGHT + PNG_GAP;
        } else { 
            currentX += PNG_KEYBOARD_WIDTH + PNG_GAP;
        }
    }

    const dataURL = canvas.toDataURL('image/png');
    const link = document.createElement('a');
    link.href = dataURL;
    link.download = 'keyboard_transpositions.png';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    if(errorDiv) errorDiv.textContent = 'PNG export initiated.';
     setTimeout(() => {
        if(errorDiv && errorDiv.textContent === 'PNG export initiated.') errorDiv.textContent = '';
    }, 3000);
}

function handleToggleSharpFlatDisplay() {
    const toggleButton = document.getElementById('toggle-sharp-flat-button');
    if (!toggleButton) return;

    if (displayModeForBlackKeys === 'sharps') {
        displayModeForBlackKeys = 'flats';
        toggleButton.textContent = 'Display Sharps';
    } else {
        displayModeForBlackKeys = 'sharps';
        toggleButton.textContent = 'Display Flats';
    }
    
    const keyboardsContainer = document.getElementById('keyboards-container');
    if (keyboardsContainer && keyboardsContainer.children.length > 0) {
        renderTranspositions();
    }
}

function handleToggleShowAllOctavesMode() {
    const toggleButton = document.getElementById('toggle-all-octaves-button');
    if (!toggleButton) return;

    showAllOctavesMode = !showAllOctavesMode;
    toggleButton.textContent = showAllOctavesMode ? 'Show Original Octaves' : 'Show All Octaves';

    const keyboardsContainer = document.getElementById('keyboards-container');
    if (keyboardsContainer && keyboardsContainer.children.length > 0) {
        renderTranspositions();
    }
}


// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    const visualizeButton = document.getElementById('visualize-button');
    if (visualizeButton) {
        visualizeButton.addEventListener('click', renderTranspositions);
    }

    const exportPngButton = document.getElementById('export-png-button');
    if (exportPngButton) {
        exportPngButton.addEventListener('click', handleExportToPng);
    }

    const toggleSharpFlatButton = document.getElementById('toggle-sharp-flat-button');
    if (toggleSharpFlatButton) {
        toggleSharpFlatButton.addEventListener('click', handleToggleSharpFlatDisplay);
    }

    const toggleAllOctavesButton = document.getElementById('toggle-all-octaves-button');
    if (toggleAllOctavesButton) {
        toggleAllOctavesButton.addEventListener('click', handleToggleShowAllOctavesMode);
    }

    const noteInput = document.getElementById('note-input') as HTMLInputElement;
    if(noteInput) {
        noteInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                event.preventDefault(); 
                renderTranspositions();
            }
        });
    }
});